local Api = true
if Api == true then
local Root = {}
local Part = game:GetService("Players").LocalPlayer.Character.HumanoidRootPart
end)

local Hum = {}
local Part = {} game:GetService("Players").LocalPlayer.Character.Humanoid
end)

local function() = {}
local Part = {} game:function()
end)
   return Root 
  return Part
 return Hum 
  return Part
return function()
  return Part
end